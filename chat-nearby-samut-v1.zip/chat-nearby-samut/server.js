'use strict';
require('dotenv').config?.();
const express = require('express');
const helmet = require('helmet');
const cookieParser = require('cookie-parser');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const Database = require('better-sqlite3');
const multer = require('multer');
const rateLimit = require('express-rate-limit');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = Number(process.env.PORT || 3000);
const SECRET = process.env.JWT_SECRET;
if (!SECRET || SECRET.length < 32) {
  console.error('กรุณากำหนด JWT_SECRET ในไฟล์ .env ให้ยาวอย่างน้อย 32 ตัวอักษร');
  process.exit(1);
}
const ROOT = __dirname;
const uploadDir = path.join(ROOT, 'uploads');
fs.mkdirSync(uploadDir, {recursive:true});
const db = new Database(path.join(ROOT, 'data', 'chat.sqlite'));
db.pragma('journal_mode = WAL');
db.exec(`
CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 username TEXT NOT NULL UNIQUE,
 password_hash TEXT NOT NULL,
 display_name TEXT NOT NULL,
 district INTEGER NOT NULL CHECK(district BETWEEN 0 AND 2),
 created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS messages (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 user_id INTEGER NOT NULL REFERENCES users(id),
 room TEXT NOT NULL,
 text TEXT NOT NULL DEFAULT '',
 image_url TEXT,
 created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS private_messages (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 sender_id INTEGER NOT NULL REFERENCES users(id),
 recipient_id INTEGER NOT NULL REFERENCES users(id),
 text TEXT NOT NULL DEFAULT '',
 image_url TEXT,
 created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS reports (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 reporter_id INTEGER NOT NULL REFERENCES users(id),
 message_id INTEGER NOT NULL,
 reason TEXT NOT NULL,
 created_at INTEGER NOT NULL
);
`);
const districts = ['อ.เมือง','อ.อัมพวา','อ.บางคนที'];
const clients = new Set();
const now = () => Date.now();

app.use(helmet({contentSecurityPolicy:false}));
app.use(express.json({limit:'1mb'}));
app.use(cookieParser());
app.use('/uploads', express.static(uploadDir, { fallthrough:false, maxAge:'1d' }));
app.use(express.static(path.join(ROOT,'public')));

const authLimit = rateLimit({windowMs:15*60*1000, limit:12, standardHeaders:true, legacyHeaders:false});
const sendLimit = rateLimit({windowMs:60*1000, limit:20, standardHeaders:true, legacyHeaders:false});
function auth(req,res,next) {
  const token = req.cookies.chat_token;
  if (!token) return res.status(401).json({error:'กรุณาเข้าสู่ระบบ'});
  try { req.user = jwt.verify(token, SECRET); next(); }
  catch { res.clearCookie('chat_token'); return res.status(401).json({error:'เซสชันหมดอายุ กรุณาเข้าสู่ระบบใหม่'}); }
}
function publicUser(row) {
  return {id:row.id, name:row.display_name, district:row.district, districtName:districts[row.district]};
}
function broadcast(type, payload) {
  const data = `event: ${type}\ndata: ${JSON.stringify(payload)}\n\n`;
  for (const res of clients) res.write(data);
}
function getRecent(room) {
  return db.prepare(`SELECT m.id,m.user_id AS userId,m.room,m.text,m.image_url AS imageUrl,m.created_at AS ts,
    u.display_name AS name,u.district FROM messages m JOIN users u ON u.id=m.user_id
    WHERE m.room=? ORDER BY m.id DESC LIMIT 100`).all(room).reverse();
}
function roomAllowed(room) { return ['general','checkpoint'].includes(room); }

app.post('/api/register', authLimit, async (req,res) => {
  const {username,password,name,district} = req.body || {};
  if (typeof username!=='string' || !/^[a-zA-Z0-9_]{4,20}$/.test(username))
    return res.status(400).json({error:'ชื่อบัญชีต้องมี 4–20 ตัว และใช้ a-z, 0-9 หรือ _'});
  if (typeof password!=='string' || password.length<8 || password.length>72)
    return res.status(400).json({error:'รหัสผ่านต้องมี 8–72 ตัวอักษร'});
  if (typeof name!=='string' || !name.trim() || name.trim().length>24)
    return res.status(400).json({error:'กรุณาตั้งชื่อแสดงผลไม่เกิน 24 ตัวอักษร'});
  const d = Number(district);
  if (!Number.isInteger(d) || d<0 || d>2) return res.status(400).json({error:'กรุณาเลือกอำเภอ'});
  try {
    const hash = await bcrypt.hash(password,12);
    const result = db.prepare('INSERT INTO users(username,password_hash,display_name,district,created_at) VALUES(?,?,?,?,?)')
      .run(username.toLowerCase(),hash,name.trim(),d,now());
    const user = {id:Number(result.lastInsertRowid)};
    const token = jwt.sign(user,SECRET,{expiresIn:'7d'});
    res.cookie('chat_token',token,{httpOnly:true,sameSite:'lax',secure:process.env.NODE_ENV==='production',maxAge:7*86400000});
    res.json({user:{...user,name:name.trim(),district:d,districtName:districts[d]}});
  } catch(e) {
    if (String(e.code)==='SQLITE_CONSTRAINT_UNIQUE') return res.status(409).json({error:'ชื่อบัญชีนี้ถูกใช้แล้ว'});
    console.error(e); res.status(500).json({error:'สมัครสมาชิกไม่สำเร็จ'});
  }
});
app.post('/api/login', authLimit, async (req,res) => {
  const {username,password} = req.body || {};
  if (typeof username!=='string' || typeof password!=='string') return res.status(400).json({error:'กรอกชื่อบัญชีและรหัสผ่าน'});
  const row = db.prepare('SELECT * FROM users WHERE username=?').get(username.toLowerCase());
  if (!row || !(await bcrypt.compare(password,row.password_hash))) return res.status(401).json({error:'ชื่อบัญชีหรือรหัสผ่านไม่ถูกต้อง'});
  const token = jwt.sign({id:row.id},SECRET,{expiresIn:'7d'});
  res.cookie('chat_token',token,{httpOnly:true,sameSite:'lax',secure:process.env.NODE_ENV==='production',maxAge:7*86400000});
  res.json({user:publicUser(row)});
});
app.post('/api/logout',(req,res)=>{res.clearCookie('chat_token');res.json({ok:true});});
app.get('/api/me',auth,(req,res)=>{
 const row=db.prepare('SELECT * FROM users WHERE id=?').get(req.user.id);
 if(!row) return res.status(401).json({error:'ไม่พบบัญชี'});
 res.json({user:publicUser(row)});
});
app.get('/api/people',auth,(req,res)=>{
 const rows=db.prepare('SELECT id,display_name,district FROM users WHERE id<>? ORDER BY display_name LIMIT 200').all(req.user.id);
 res.json(rows.map(publicUser));
});
app.get('/api/messages',auth,(req,res)=>{
 const room=String(req.query.room||'general');
 if(!roomAllowed(room)) return res.status(400).json({error:'ห้องแชตไม่ถูกต้อง'});
 res.json({messages:getRecent(room)});
});

const storage=multer.diskStorage({
 destination:(req,file,cb)=>cb(null,uploadDir),
 filename:(req,file,cb)=>cb(null,`${Date.now()}-${require('crypto').randomBytes(8).toString('hex')}${path.extname(file.originalname).toLowerCase()}`)
});
const imageUpload=multer({storage,limits:{fileSize:5*1024*1024},fileFilter:(req,file,cb)=>{
 const ok=['image/jpeg','image/png','image/webp','image/gif'].includes(file.mimetype);
 cb(ok?null:new Error('รองรับเฉพาะ JPG, PNG, WEBP และ GIF'),ok);
}});
app.post('/api/upload',auth,sendLimit,(req,res)=>{
 imageUpload.single('image')(req,res,err=>{
   if(err) return res.status(400).json({error:err.message||'อัปโหลดไม่สำเร็จ'});
   if(!req.file) return res.status(400).json({error:'ไม่พบรูปภาพ'});
   res.json({url:`/uploads/${req.file.filename}`});
 });
});
app.post('/api/send',auth,sendLimit,(req,res)=>{
 const room=String(req.body.room||'general');
 const text=typeof req.body.text==='string'?req.body.text.trim():'';
 const imageUrl=typeof req.body.imageUrl==='string'?req.body.imageUrl:'';
 if(!roomAllowed(room)) return res.status(400).json({error:'ห้องแชตไม่ถูกต้อง'});
 if(!text && !imageUrl) return res.status(400).json({error:'กรุณาพิมพ์ข้อความหรือแนบรูป'});
 if(text.length>1000) return res.status(400).json({error:'ข้อความยาวเกิน 1,000 ตัวอักษร'});
 if(imageUrl && !/^\/uploads\/[a-zA-Z0-9._-]+$/.test(imageUrl)) return res.status(400).json({error:'ไฟล์รูปไม่ถูกต้อง'});
 const user=db.prepare('SELECT id,display_name,district FROM users WHERE id=?').get(req.user.id);
 const result=db.prepare('INSERT INTO messages(user_id,room,text,image_url,created_at) VALUES(?,?,?,?,?)').run(user.id,room,text,imageUrl||null,now());
 const message={id:Number(result.lastInsertRowid),userId:user.id,name:user.display_name,district:user.district,room,text,imageUrl:imageUrl||null,ts:now()};
 broadcast('message',message); res.json({message});
});
app.post('/api/private-send',auth,sendLimit,(req,res)=>{
 const to=Number(req.body.to), text=typeof req.body.text==='string'?req.body.text.trim():'';
 if(!Number.isInteger(to)||to===req.user.id||!text||text.length>1000) return res.status(400).json({error:'ข้อมูลข้อความส่วนตัวไม่ถูกต้อง'});
 if(!db.prepare('SELECT id FROM users WHERE id=?').get(to)) return res.status(404).json({error:'ไม่พบผู้ใช้'});
 const result=db.prepare('INSERT INTO private_messages(sender_id,recipient_id,text,created_at) VALUES(?,?,?,?)').run(req.user.id,to,text,now());
 const message={id:Number(result.lastInsertRowid),from:req.user.id,to,text,ts:now()};
 broadcast('private',message); res.json({message});
});
app.get('/api/private/:userId',auth,(req,res)=>{
 const other=Number(req.params.userId);
 const rows=db.prepare(`SELECT id,sender_id AS senderId,recipient_id AS recipientId,text,created_at AS ts
 FROM private_messages WHERE (sender_id=? AND recipient_id=?) OR (sender_id=? AND recipient_id=?) ORDER BY id DESC LIMIT 100`)
 .all(req.user.id,other,other,req.user.id).reverse();
 res.json({messages:rows});
});
app.post('/api/report',auth,sendLimit,(req,res)=>{
 const id=Number(req.body.messageId), reason=String(req.body.reason||'').trim().slice(0,300);
 if(!Number.isInteger(id)||!reason) return res.status(400).json({error:'กรุณาระบุข้อความและเหตุผล'});
 db.prepare('INSERT INTO reports(reporter_id,message_id,reason,created_at) VALUES(?,?,?,?)').run(req.user.id,id,reason,now());
 res.json({ok:true});
});
app.get('/events',auth,(req,res)=>{
 res.set({'Content-Type':'text/event-stream','Cache-Control':'no-cache, no-transform','Connection':'keep-alive','X-Accel-Buffering':'no'});
 res.flushHeaders?.(); clients.add(res);
 const send=(event,data)=>res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`);
 send('init',{user:req.user.id,messages:{general:getRecent('general'),checkpoint:getRecent('checkpoint')}});
 const heartbeat=setInterval(()=>res.write(': ping\n\n'),25000);
 req.on('close',()=>{clearInterval(heartbeat);clients.delete(res);});
});
app.use((err,req,res,next)=>{console.error(err); if(!res.headersSent)res.status(500).json({error:'เกิดข้อผิดพลาดในเซิร์ฟเวอร์'});});
app.listen(PORT,()=>console.log(`Chat server running on http://localhost:${PORT}`));
